# -*- coding: utf-8 -*-
# Copyright 2025 HungryDev
# License LGPL-3.0 or later (https://www.gnu.org/licenses/lgpl).

from . import account_invoice_ubl_export_wizard
